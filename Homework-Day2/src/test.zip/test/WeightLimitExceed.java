package test;

public class WeightLimitExceed extends RuntimeException{

	private static final long serialVersionUID = 1L;
	public WeightLimitExceed(){
		super();
	}

}
